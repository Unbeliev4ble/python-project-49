
from cli import welcome_user
from random import randint


def is_number_even():
    even_game_number = randint(1, 100)
    possible_user_answers = ['yes', 'no']
    print('Answer "yes" if the number is even, otherwise answer "no".')
    print(f'Question: {even_game_number}')
    user_even_game_answer = prompt.string('Your answer: ')
    while user_even_game_answer.lower() not in possible_user_answers:
        user_even_game_answer = prompt.string('You should answer "yes" or "no", so is this number even? ')
    if user_even_game_answer.lower() == 'yes' and even_game_number % 2 == 0:
        print('Correct!')
    else:
        possible_user_answers.remove(user_even_game_answer.lower())
        print(f"{user_even_game_answer} is wrong answer ;(. Correct answer was '{possible_user_answers[0]}'")
        print(f"Let's try again ASASASAS!")

welcome_user()
is_number_even()