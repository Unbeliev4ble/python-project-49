#!/usr/bin/env python3

from brain_games.brain_games_even import welcome_user, is_number_even


def main():
    welcome_user()
    is_number_even()


if __name__ == 'main':
    main()
