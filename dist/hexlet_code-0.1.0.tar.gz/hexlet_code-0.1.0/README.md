### Hexlet tests and linter status:
[![Actions Status](https://github.com/Unbeliev4ble/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Unbeliev4ble/python-project-49/actions)

### Сodeclimate Maintainability badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/07a25930bbd5ded6b395/maintainability)](https://codeclimate.com/github/Unbeliev4ble/python-project-49/maintainability)


### Asciinema demonstration
[https://asciinema.org/a/ytPsf8eSG4V4RjRG4bShdydb4]