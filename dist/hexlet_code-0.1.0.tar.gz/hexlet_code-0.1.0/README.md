### Hexlet tests and linter status:
[![Actions Status](https://github.com/Unbeliev4ble/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Unbeliev4ble/python-project-49/actions)

### Сodeclimate Maintainability badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/07a25930bbd5ded6b395/maintainability)](https://codeclimate.com/github/Unbeliev4ble/python-project-49/maintainability)


### Asciinema demonstrations
# brain-even
[https://asciinema.org/a/UPXubEnzWx3NVcfJzk3LRHmWb]
# brain-calc
[https://asciinema.org/a/O7wm3ZL9SfDYYIYNhmRcD5HfG]